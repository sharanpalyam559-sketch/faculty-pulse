import React, { useMemo, useState } from "react";
import {
  ArrowRight, BarChart3, BookOpen, CheckCircle2, ChevronDown, ChevronLeft,
  ClipboardCheck, GraduationCap, LayoutDashboard, LogOut, MessageSquare,
  Plus, ShieldCheck, Star, Users, UserRound, X, Menu, Sparkles
} from "lucide-react";

const seedFaculty = [
  { id: 1, name: "Dr. Ananya Rao", subject: "Artificial Intelligence", dept: "CSE (AI)", rating: 4.6, responses: 42, initials: "AR" },
  { id: 2, name: "Prof. Kiran Kumar", subject: "Database Management Systems", dept: "CSE", rating: 4.3, responses: 38, initials: "KK" },
  { id: 3, name: "Dr. Priya Sharma", subject: "Natural Language Processing", dept: "CSE (AI)", rating: 4.8, responses: 31, initials: "PS" },
  { id: 4, name: "Prof. Ravi Teja", subject: "Operating Systems", dept: "CSE", rating: 4.1, responses: 35, initials: "RT" }
];

const seedFeedback = [
  { id: 1, facultyId: 1, student: "Anonymous", clarity: 5, knowledge: 5, engagement: 4, punctuality: 5, support: 4, comment: "Explains difficult AI concepts clearly and uses practical examples.", date: "2026-10-05" },
  { id: 2, facultyId: 1, student: "Anonymous", clarity: 4, knowledge: 5, engagement: 5, punctuality: 5, support: 4, comment: "Very interactive classes. More coding demonstrations would be helpful.", date: "2026-10-04" },
  { id: 3, facultyId: 2, student: "Anonymous", clarity: 4, knowledge: 4, engagement: 4, punctuality: 5, support: 4, comment: "Good pace and clear explanations.", date: "2026-10-03" }
];

const criteria = [
  ["clarity", "Clarity of teaching"],
  ["knowledge", "Subject knowledge"],
  ["engagement", "Class engagement"],
  ["punctuality", "Punctuality"],
  ["support", "Student support"]
];

function Logo({ compact=false }) {
  return <div className="flex items-center gap-3">
    <div className="h-10 w-10 rounded-2xl bg-forest text-white grid place-items-center shadow-card">
      <Sparkles size={20}/>
    </div>
    {!compact && <div>
      <div className="font-extrabold tracking-tight text-lg leading-none">FacultyPulse</div>
      <div className="text-xs text-muted mt-1">Faculty Feedback System</div>
    </div>}
  </div>;
}

function RatingStars({ value, size=17 }) {
  return <div className="flex gap-0.5">
    {[1,2,3,4,5].map(n => <Star key={n} size={size} fill={n <= Math.round(value) ? "#d7a84c" : "none"} stroke={n <= Math.round(value) ? "#d7a84c" : "#bdc9c2"}/>)}
  </div>;
}

function Auth({ onLogin }) {
  const [role, setRole] = useState("student");
  const [roll, setRoll] = useState("");
  const [password, setPassword] = useState("");
  const [signup, setSignup] = useState(false);

  const submit = e => {
    e.preventDefault();
    onLogin({ role, name: role === "admin" ? "Administrator" : (roll || "CSE3A001"), roll: roll || "CSE3A001" });
  };

  return <div className="auth-bg grid-pattern min-h-screen flex items-center justify-center p-5">
    <div className="w-full max-w-6xl grid lg:grid-cols-2 gap-10 items-center">
      <div className="hidden lg:block px-10 fade-in">
        <Logo />
        <h1 className="text-5xl font-black tracking-tight text-forest mt-10 leading-[1.08]">
          Honest feedback.<br/>Fully anonymous.<br/><span className="text-[#6f8c7e]">Better teaching.</span>
        </h1>
        <p className="text-muted text-lg max-w-xl mt-6 leading-8">
          Students rate each faculty on five criteria. Admins see averages, comments and trends — never who wrote them.
        </p>
        <div className="mt-8 flex gap-3 flex-wrap">
          {["Anonymous by design", "One submission per subject", "Simple analytics"].map(x =>
            <span key={x} className="bg-white/75 border border-line rounded-full px-4 py-2 text-sm font-semibold text-forest">{x}</span>
          )}
        </div>
      </div>

      <div className="bg-white/95 border border-line rounded-[30px] shadow-soft p-7 sm:p-10 max-w-md w-full mx-auto slide-up">
        <div className="lg:hidden mb-8"><Logo/></div>
        <div className="mb-7">
          <h2 className="text-2xl font-extrabold">Sign in</h2>
          <p className="text-muted text-sm mt-1">Choose your role and enter your credentials.</p>
        </div>

        <div className="grid grid-cols-2 p-1 rounded-xl bg-[#f1f5f2] mb-6">
          {["student","admin"].map(r => <button key={r} onClick={()=>setRole(r)}
            className={`py-2.5 rounded-lg text-sm font-bold capitalize transition ${role===r ? "bg-white shadow-sm text-forest" : "text-muted"}`}>
            {r}
          </button>)}
        </div>

        <form onSubmit={submit} className="space-y-4">
          {role === "student" && <div>
            <label className="text-sm font-semibold">Roll number</label>
            <input value={roll} onChange={e=>setRoll(e.target.value)} placeholder="CSE3A001"
              className="mt-1.5 w-full border border-line rounded-xl px-4 py-3.5 outline-none focus:ring-2 focus:ring-forest/15 focus:border-forest"/>
          </div>}
          <div>
            <label className="text-sm font-semibold">{role === "admin" ? "Admin username" : "Password"}</label>
            <input value={password} onChange={e=>setPassword(e.target.value)} type="password"
              placeholder={role === "admin" ? "admin" : "••••••••"}
              className="mt-1.5 w-full border border-line rounded-xl px-4 py-3.5 outline-none focus:ring-2 focus:ring-forest/15 focus:border-forest"/>
          </div>
          <button className="w-full bg-forest hover:bg-[#12332c] text-white rounded-xl py-3.5 font-bold flex items-center justify-center gap-2 transition">
            Sign in <ArrowRight size={17}/>
          </button>
        </form>

        <div className="text-center mt-6 text-sm text-muted">
          No account yet? <button onClick={()=>setSignup(!signup)} className="font-bold text-forest hover:underline">Create one</button>
        </div>

        {signup && <div className="mt-5 rounded-2xl bg-mint border border-[#cfe1d5] p-4 text-sm">
          <b className="text-forest">Demo account</b>
          <p className="text-muted mt-1">This front-end stores data locally. Any roll number can sign in as a student.</p>
        </div>}

        <div className="flex items-center justify-center gap-2 mt-7 text-xs text-muted">
          <ShieldCheck size={14}/> Your feedback is designed to remain anonymous
        </div>
      </div>
    </div>
  </div>;
}

function Student({ user, faculty, feedback, setFeedback, logout }) {
  const [selected, setSelected] = useState(null);
  const [done, setDone] = useState(false);

  const submitted = selected && feedback.some(f => f.facultyId === selected.id && f.student === user.roll);

  const save = values => {
    setFeedback(prev => [...prev, { id: Date.now(), facultyId: selected.id, student: user.roll, ...values, date: new Date().toISOString().slice(0,10) }]);
    setDone(true);
  };

  if (done) return <div className="min-h-screen bg-cream grid place-items-center p-5">
    <div className="bg-white border border-line rounded-3xl shadow-soft max-w-lg w-full p-10 text-center slide-up">
      <div className="w-16 h-16 rounded-full bg-mint text-forest grid place-items-center mx-auto"><CheckCircle2 size={34}/></div>
      <h2 className="text-2xl font-extrabold mt-5">Feedback submitted</h2>
      <p className="text-muted mt-2">Thank you. Your response has been recorded anonymously.</p>
      <button onClick={()=>{setDone(false);setSelected(null)}} className="mt-7 bg-forest text-white rounded-xl px-6 py-3 font-bold">Back to faculty</button>
    </div>
  </div>;

  return <div className="min-h-screen bg-cream">
    <Topbar user={user} logout={logout}/>
    <main className="max-w-6xl mx-auto px-5 py-10">
      {!selected ? <>
        <div className="mb-8">
          <p className="text-sm text-muted font-semibold">Student dashboard</p>
          <h1 className="text-3xl sm:text-4xl font-black text-forest mt-1">Give honest feedback</h1>
          <p className="text-muted mt-2">Choose a faculty member and rate your experience across five criteria.</p>
        </div>
        <div className="grid md:grid-cols-2 gap-5">
          {faculty.map(f => {
            const isDone = feedback.some(x=>x.facultyId===f.id && x.student===user.roll);
            return <button key={f.id} onClick={()=>!isDone && setSelected(f)} className={`text-left bg-white border border-line rounded-2xl p-6 shadow-card transition ${isDone ? "opacity-70" : "hover:-translate-y-1 hover:shadow-soft"}`}>
              <div className="flex items-start justify-between gap-4">
                <div className="flex gap-4">
                  <div className="h-12 w-12 rounded-2xl bg-mint text-forest font-extrabold grid place-items-center">{f.initials}</div>
                  <div>
                    <h3 className="font-extrabold text-lg">{f.name}</h3>
                    <p className="text-sm text-muted mt-0.5">{f.subject}</p>
                  </div>
                </div>
                {isDone ? <span className="text-xs font-bold text-forest bg-mint px-3 py-1.5 rounded-full">Submitted</span> : <ArrowRight className="text-muted" size={19}/>}
              </div>
              <div className="mt-6 flex items-center gap-3">
                <RatingStars value={f.rating}/>
                <span className="font-bold">{f.rating.toFixed(1)}</span>
                <span className="text-xs text-muted">overall</span>
              </div>
            </button>
          })}
        </div>
      </> : <FeedbackForm faculty={selected} onBack={()=>setSelected(null)} onSubmit={save} />}
    </main>
  </div>;
}

function FeedbackForm({ faculty, onBack, onSubmit }) {
  const [values, setValues] = useState(Object.fromEntries(criteria.map(([k])=>[k,0])));
  const [comment, setComment] = useState("");

  const submit = e => {
    e.preventDefault();
    if (Object.values(values).some(v=>v===0)) return alert("Please rate all five criteria.");
    onSubmit({...values, comment});
  };

  return <div className="max-w-3xl mx-auto slide-up">
    <button onClick={onBack} className="flex items-center gap-2 text-sm font-bold text-muted hover:text-forest"><ChevronLeft size={17}/> Back to faculty</button>
    <div className="bg-white border border-line rounded-3xl shadow-card mt-5 overflow-hidden">
      <div className="bg-forest text-white p-7 sm:p-9">
        <div className="flex items-center gap-4">
          <div className="h-14 w-14 rounded-2xl bg-white/10 grid place-items-center font-black">{faculty.initials}</div>
          <div><h1 className="text-2xl font-black">{faculty.name}</h1><p className="text-white/70 mt-1">{faculty.subject} · {faculty.dept}</p></div>
        </div>
        <div className="mt-6 text-sm text-white/75 flex gap-2 items-center"><ShieldCheck size={16}/> Your identity will not be shown to faculty or administrators.</div>
      </div>
      <form onSubmit={submit} className="p-7 sm:p-9">
        <h2 className="font-extrabold text-xl">Rate this faculty</h2>
        <p className="text-sm text-muted mt-1 mb-7">1 = Needs improvement · 5 = Excellent</p>
        <div className="space-y-4">
          {criteria.map(([key,label]) => <div key={key} className="border border-line rounded-2xl p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <span className="font-bold">{label}</span>
            <div className="flex gap-2">
              {[1,2,3,4,5].map(n => <button type="button" key={n} onClick={()=>setValues(v=>({...v,[key]:n}))}
                className={`rating w-10 h-10 rounded-xl font-extrabold border ${values[key]===n ? "bg-forest text-white border-forest" : "bg-white text-muted border-line hover:border-forest"}`}>{n}</button>)}
            </div>
          </div>)}
        </div>
        <div className="mt-7">
          <label className="font-bold">Additional comments <span className="font-normal text-muted">(optional)</span></label>
          <textarea value={comment} onChange={e=>setComment(e.target.value)} rows="5" placeholder="Share a constructive comment..."
            className="mt-2 w-full border border-line rounded-2xl px-4 py-3 outline-none resize-none focus:border-forest focus:ring-2 focus:ring-forest/10"/>
        </div>
        <button className="mt-6 w-full bg-forest hover:bg-[#12332c] text-white rounded-xl py-3.5 font-bold flex items-center justify-center gap-2">Submit anonymously <ArrowRight size={17}/></button>
      </form>
    </div>
  </div>;
}

function Topbar({ user, logout }) {
  return <header className="bg-white border-b border-line sticky top-0 z-20">
    <div className="max-w-6xl mx-auto px-5 h-[72px] flex items-center justify-between">
      <Logo/>
      <div className="flex items-center gap-3">
        <div className="hidden sm:block text-right"><div className="text-sm font-bold">{user.name}</div><div className="text-xs text-muted capitalize">{user.role}</div></div>
        <button onClick={logout} title="Sign out" className="w-10 h-10 rounded-xl border border-line grid place-items-center text-muted hover:text-forest hover:bg-mint"><LogOut size={17}/></button>
      </div>
    </div>
  </header>;
}

function Admin({ faculty, feedback, setFaculty, logout }) {
  const [page, setPage] = useState("overview");
  const [mobile, setMobile] = useState(false);
  const [showAdd, setShowAdd] = useState(false);

  const totalResponses = feedback.length;
  const overall = feedback.length ? feedback.reduce((s,f)=>s + criteria.reduce((a,[k])=>a+f[k],0)/5,0)/feedback.length : 0;

  const enriched = faculty.map(f => {
    const rows = feedback.filter(x=>x.facultyId===f.id);
    const avg = rows.length ? rows.reduce((s,r)=>s+criteria.reduce((a,[k])=>a+r[k],0)/5,0)/rows.length : f.rating;
    return {...f, rating: avg, responses: rows.length};
  });

  const addFaculty = data => {
    setFaculty(prev=>[...prev,{...data,id:Date.now(),initials:data.name.split(" ").map(x=>x[0]).slice(0,2).join("").toUpperCase(),rating:0,responses:0}]);
    setShowAdd(false);
  };

  return <div className="min-h-screen bg-cream">
    <header className="bg-white border-b border-line h-[72px] sticky top-0 z-30">
      <div className="max-w-[1400px] mx-auto px-5 h-full flex items-center justify-between">
        <div className="flex items-center gap-4"><button onClick={()=>setMobile(!mobile)} className="lg:hidden"><Menu/></button><Logo/></div>
        <button onClick={logout} className="flex items-center gap-2 text-sm font-bold text-muted hover:text-forest"><LogOut size={17}/> <span className="hidden sm:inline">Sign out</span></button>
      </div>
    </header>
    <div className="max-w-[1400px] mx-auto flex">
      <aside className={`${mobile ? "block absolute z-20 shadow-xl" : "hidden"} lg:block w-64 shrink-0 bg-white border-r border-line min-h-[calc(100vh-72px)]`}>
        <nav className="p-4 space-y-1">
          {[["overview",LayoutDashboard,"Overview"],["faculty",Users,"Faculty"],["feedback",MessageSquare,"Feedback"]].map(([id,Icon,label]) =>
            <button key={id} onClick={()=>{setPage(id);setMobile(false)}} className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold ${page===id ? "bg-mint text-forest" : "text-muted hover:bg-gray-50"}`}><Icon size={18}/>{label}</button>
          )}
        </nav>
      </aside>

      <main className="flex-1 min-w-0 p-5 sm:p-8">
        {page==="overview" && <Overview faculty={enriched} feedback={feedback} totalResponses={totalResponses} overall={overall}/>}
        {page==="faculty" && <FacultyPage faculty={enriched} onAdd={()=>setShowAdd(true)}/>}
        {page==="feedback" && <FeedbackPage faculty={enriched} feedback={feedback}/>}
      </main>
    </div>
    {showAdd && <AddFaculty onClose={()=>setShowAdd(false)} onAdd={addFaculty}/>}
  </div>;
}

function Overview({faculty, feedback, totalResponses, overall}) {
  return <div className="slide-up">
    <div className="mb-8"><p className="text-sm font-semibold text-muted">Administrator</p><h1 className="text-3xl sm:text-4xl font-black text-forest mt-1">Dashboard overview</h1><p className="text-muted mt-2">A clear view of teaching feedback across your department.</p></div>
    <div className="grid sm:grid-cols-2 xl:grid-cols-4 gap-4">
      {[
        ["Total faculty",faculty.length,Users],
        ["Responses",totalResponses,ClipboardCheck],
        ["Overall rating",overall ? overall.toFixed(1) : "—",Star],
        ["Subjects covered",faculty.length,BookOpen]
      ].map(([label,value,Icon])=><div key={label} className="bg-white border border-line rounded-2xl p-5 shadow-card"><div className="w-10 h-10 bg-mint text-forest rounded-xl grid place-items-center"><Icon size={19}/></div><p className="text-sm text-muted mt-4">{label}</p><div className="text-3xl font-black mt-1">{value}</div></div>)}
    </div>
    <div className="grid xl:grid-cols-3 gap-5 mt-6">
      <div className="xl:col-span-2 bg-white border border-line rounded-2xl p-6 shadow-card">
        <div className="flex items-center justify-between"><div><h2 className="font-extrabold text-lg">Faculty performance</h2><p className="text-sm text-muted mt-1">Average rating from anonymous responses.</p></div><BarChart3 className="text-muted"/></div>
        <div className="mt-6 space-y-5">{faculty.map(f=><div key={f.id}>
          <div className="flex justify-between text-sm mb-2"><span className="font-bold">{f.name}</span><span className="font-extrabold">{f.rating.toFixed(1)}</span></div>
          <div className="h-2 bg-[#edf1ee] rounded-full overflow-hidden"><div className="h-full bg-forest rounded-full" style={{width:`${Math.min(100,f.rating/5*100)}%`}}/></div>
        </div>)}</div>
      </div>
      <div className="bg-forest text-white rounded-2xl p-6 shadow-card">
        <div className="flex items-center gap-2 font-bold"><ShieldCheck size={19}/> Anonymous by design</div>
        <h2 className="text-2xl font-black mt-6">Honest answers lead to better teaching.</h2>
        <p className="text-white/70 mt-3 text-sm leading-6">Students are represented anonymously in the feedback view. Use trends and comments to identify what is working and what needs attention.</p>
      </div>
    </div>
  </div>;
}

function FacultyPage({faculty,onAdd}) {
  return <div className="slide-up">
    <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
      <div><p className="text-sm font-semibold text-muted">Administration</p><h1 className="text-3xl font-black text-forest mt-1">Faculty</h1><p className="text-muted mt-2">Manage faculty and view their current ratings.</p></div>
      <button onClick={onAdd} className="bg-forest text-white px-5 py-3 rounded-xl font-bold flex items-center gap-2"><Plus size={18}/> Add faculty</button>
    </div>
    <div className="grid md:grid-cols-2 gap-5">
      {faculty.map(f=><div key={f.id} className="bg-white border border-line rounded-2xl p-6 shadow-card">
        <div className="flex gap-4"><div className="w-12 h-12 rounded-2xl bg-mint text-forest grid place-items-center font-black">{f.initials}</div><div><h3 className="font-extrabold">{f.name}</h3><p className="text-sm text-muted">{f.subject}</p><p className="text-xs text-muted mt-1">{f.dept}</p></div></div>
        <div className="mt-6 pt-5 border-t border-line flex justify-between items-center"><div><RatingStars value={f.rating}/><p className="text-xs text-muted mt-1">{f.responses} responses</p></div><span className="text-2xl font-black text-forest">{f.rating.toFixed(1)}</span></div>
      </div>)}
    </div>
  </div>;
}

function FeedbackPage({faculty,feedback}) {
  const [filter,setFilter] = useState("all");
  const rows = feedback.filter(x=>filter==="all" || String(x.facultyId)===filter);
  return <div className="slide-up">
    <div className="mb-8"><p className="text-sm font-semibold text-muted">Anonymous responses</p><h1 className="text-3xl font-black text-forest mt-1">Feedback</h1><p className="text-muted mt-2">Read comments and inspect rating details without student identities.</p></div>
    <select value={filter} onChange={e=>setFilter(e.target.value)} className="bg-white border border-line rounded-xl px-4 py-3 mb-5 outline-none">
      <option value="all">All faculty</option>{faculty.map(f=><option key={f.id} value={f.id}>{f.name}</option>)}
    </select>
    <div className="space-y-4">{rows.length ? rows.map(r=>{
      const f=faculty.find(x=>x.id===r.facultyId);
      const avg=criteria.reduce((a,[k])=>a+r[k],0)/5;
      return <div key={r.id} className="bg-white border border-line rounded-2xl p-6 shadow-card">
        <div className="flex flex-col sm:flex-row sm:justify-between gap-3"><div><div className="font-extrabold">{f?.name}</div><div className="text-sm text-muted">{f?.subject} · {r.date}</div></div><div className="flex items-center gap-2"><RatingStars value={avg}/><b>{avg.toFixed(1)}</b></div></div>
        <p className="mt-5 text-sm leading-6 text-[#45534d]">{r.comment || "No additional comment."}</p>
        <div className="mt-5 grid grid-cols-2 sm:grid-cols-5 gap-2">{criteria.map(([k,l])=><div key={k} className="bg-[#f6f8f6] rounded-xl p-3"><p className="text-[11px] text-muted">{l}</p><p className="font-black mt-1">{r[k]}/5</p></div>)}</div>
      </div>;
    }) : <div className="bg-white border border-line rounded-2xl p-10 text-center text-muted">No feedback found.</div>}</div>
  </div>;
}

function AddFaculty({onClose,onAdd}) {
  const [name,setName]=useState(""); const [subject,setSubject]=useState(""); const [dept,setDept]=useState("");
  return <div className="fixed inset-0 z-50 bg-black/30 backdrop-blur-sm grid place-items-center p-5">
    <form onSubmit={e=>{e.preventDefault();if(name&&subject)onAdd({name,subject,dept:dept||"CSE"})}} className="bg-white w-full max-w-md rounded-3xl shadow-soft p-7">
      <div className="flex justify-between items-center"><h2 className="text-xl font-black">Add faculty</h2><button type="button" onClick={onClose}><X/></button></div>
      {[["Name",name,setName,"Dr. Faculty Name"],["Subject",subject,setSubject,"Subject name"],["Department",dept,setDept,"CSE (AI)"]].map(([l,v,s,p])=><div key={l} className="mt-5"><label className="text-sm font-bold">{l}</label><input value={v} onChange={e=>s(e.target.value)} placeholder={p} className="mt-1.5 w-full border border-line rounded-xl px-4 py-3 outline-none focus:border-forest"/></div>)}
      <button className="mt-6 w-full bg-forest text-white py-3.5 rounded-xl font-bold">Add faculty</button>
    </form>
  </div>;
}

export default function App() {
  const [user,setUser] = useState(null);
  const [faculty,setFaculty] = useState(()=>JSON.parse(localStorage.getItem("fp_faculty") || "null") || seedFaculty);
  const [feedback,setFeedback] = useState(()=>JSON.parse(localStorage.getItem("fp_feedback") || "null") || seedFeedback);

  React.useEffect(()=>localStorage.setItem("fp_faculty",JSON.stringify(faculty)),[faculty]);
  React.useEffect(()=>localStorage.setItem("fp_feedback",JSON.stringify(feedback)),[feedback]);

  if (!user) return <Auth onLogin={setUser}/>;
  if (user.role === "admin") return <Admin faculty={faculty} feedback={feedback} setFaculty={setFaculty} logout={()=>setUser(null)}/>;
  return <Student user={user} faculty={faculty} feedback={feedback} setFeedback={setFeedback} logout={()=>setUser(null)}/>;
}